package com.bigdata.orderingsystem.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

// Ctrl + Alt + O

@Controller
@ResponseBody
@RequestMapping("/test")
public class HelloController {
    // http://ip:port/hello
    // http://127.0.0.1:8080/hello
    @GetMapping("/hello")
    public String hello() {
        return "HELLO SPRINGBOOT";
    }

    // 路径信息传参
    // http://127.0.0.1:8080/test/hi?name=123
    // http://127.0.0.1:8080/test/hi?name=Jenny&money=999
    @GetMapping("/hi")
    public String aaa(String name, Double money) {
        return "HI " + name + ", 存款: " + money;
    }

    // @PostMapping
    // @PutMapping
    // @DeleteMapping
}
