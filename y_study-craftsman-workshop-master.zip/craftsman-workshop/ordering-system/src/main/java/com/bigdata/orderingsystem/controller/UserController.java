package com.bigdata.orderingsystem.controller;

import com.bigdata.orderingsystem.dao.UserDao;
import com.bigdata.orderingsystem.entity.User;
import com.bigdata.orderingsystem.util.ResponseMessage;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;


@Controller
@ResponseBody
@RequestMapping("/user")
public class UserController {
    // 依赖注入
    @Autowired
    private UserDao userDao;

    /**
     * 新增用户
     *
     * @param user
     * @return
     */
    @PostMapping("/save")
    public ResponseMessage save(@RequestBody User user) {
        Date date = new Date();
        user.setCreateTime(date);
        user.setUpdateTime(date);
        return ResponseMessage.success(userDao.save(user));
    }

    @PutMapping("/update")
    public ResponseMessage update(@RequestBody User user) {
        user.setUpdateTime(new Date());
        return ResponseMessage.success(userDao.update(user));
    }

    @DeleteMapping("/deleteById")
    public ResponseMessage deleteById(Long id) {
        return ResponseMessage.success(userDao.deleteById(id));
    }

    @GetMapping("/getById")
    public ResponseMessage getById(Long id) {
        return ResponseMessage.success(userDao.selectById(id));
    }

    /**
     * 用户列表
     */
    @GetMapping("/list")
    public ResponseMessage list() {
        return ResponseMessage.success(userDao.list());
    }
}
