package com.bigdata.orderingsystem.dao;

import com.bigdata.orderingsystem.entity.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * DAO: Data Access Object
 * 增: @Insert
 * 删: @Delete
 * 改: @Update
 * 查: @Select
 */
@Mapper
public interface UserDao {
    /**
     * 新增用户信息
     *
     * @param user
     * @return
     */
    @Insert("INSERT INTO user (username, password, gender, phone_number, surplus, create_time, update_time) VALUES " +
            "(#{username}, #{password}, #{gender}, #{phoneNumber}, #{surplus}, #{createTime}, #{updateTime})")
    int save(User user);

    /**
     * 修改用户
     */
    @Update("UPDATE user SET username = #{username}, password = #{password}, phone_number = #{phoneNumber}, " +
            "surplus = #{surplus}, update_time = #{updateTime} WHERE id = #{id}")
    int update(User user);

    /**
     * 删除用户
     */
    @Delete("DELETE FROM user WHERE id = #{id}")
    int deleteById(Long id);

    /**
     * 根据ID查询用户
     */
    @Select("SELECT * FROM user WHERE id = #{id}")
    User selectById(Long id);

    /**
     * 查询用户列表
     */
    @Select("SELECT * FROM user ORDER BY id DESC")
    List<User> list();
}
