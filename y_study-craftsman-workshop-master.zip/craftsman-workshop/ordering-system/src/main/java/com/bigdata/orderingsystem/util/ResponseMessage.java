package com.bigdata.orderingsystem.util;

public class ResponseMessage {
    /**
     * 状态码: 200: SUCCESS
     *  500: FAIL
     */
    private Integer code;
    /**
     * 数据
     */
    private Object data;
    /**
     * 提示信息
     */
    private String message;

    /**
     * 成功返回
     *
     * @param data
     * @return
     */
    public static ResponseMessage success(Object data) {
        ResponseMessage responseMessage = new ResponseMessage();
        responseMessage.code = 200;
        responseMessage.data = data;
        responseMessage.message = "SUCCESS";
        return responseMessage;
    }

    /**
     * 失败返回
     *
     * @return
     */
    public static ResponseMessage fail() {
        ResponseMessage responseMessage = new ResponseMessage();
        responseMessage.code = 500;
        responseMessage.message = "FAIL";
        return responseMessage;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
