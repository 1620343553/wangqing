package com.bigdata.tankbattle;

import javax.swing.*;
import java.awt.*;

/**
 * 继承 JPanel 类, 重写 paint 方法
 */
public class GamePanel extends JPanel {
    // 常量
    // 面板宽度, 窗口宽度
    public static final int WIDTH = 1200;
    // 面板高度, 窗口高度
    public static final int HEIGHT = 600;

    private Tank tank;

    public GamePanel(Tank tank) {
        this.tank = tank;
    }

    // Ctrl + O
    @Override
    public void paint(Graphics g) {
        super.paint(g);

        tank.fill(g);

        Tank tank2 = new Tank();
        tank2.setX(Tank.INIT_X * 2);
        tank2.setY(Tank.INIT_Y * 2);
        tank2.setWidth(Tank.WIDTH * 2);
        tank2.setHeight(Tank.HEIGHT * 2);
        // 履带宽度
        tank2.setWheelWidth(Tank.WHEEL_WIDTH * 2);
        // halfOverflowHeight
        tank2.setHalfOverflowHeight(Tank.HALF_OVERFLOW_HEIGHT * 2);

        tank2.setBarrelHeight(Tank.BARREL_HEIGHT * 2);
        tank2.setBarrelWidth(Tank.BARREL_WIDTH * 2);
        tank2.fill(g);
    }

    /**
     * 刷新面板
     */
    public void refresh() {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    for (; ; ) {
                        repaint();
                        // Alt + Enter
                        try {
                            Thread.sleep(1000 / 60);
                        } catch (InterruptedException e) {
                            e.printStackTrace();
                        }
                    }
                }
            }).start();
    }
}
