package com.bigdata.tankbattle;

import java.awt.*;

public class Tank {
    // 常量
    // 坦克初始的x坐标
    public static final int INIT_X = 100;
    // 坦克初始的y坐标
    public static final int INIT_Y = 100;
    // 小坦克的宽度
    public static final int WIDTH = 24;
    // 小坦克的高度
    public static final int HEIGHT = 24;
    /**
     * 履带宽度
     */
    public static final int WHEEL_WIDTH = 6;
    /**
     * 履带高度减去坦克高度的差的一半
     */
    public static final int HALF_OVERFLOW_HEIGHT = 4;
    /**
     * 枪管的宽度
     */
    public static final int BARREL_WIDTH = 6;
    /**
     * 枪管的高度
     */
    public static final int BARREL_HEIGHT = 12;

    /**
     * x坐标
     */
    private int x;

    /**
     * y坐标
     */
    private int y;

    // 宽度
    private int width;

    // 高度
    private int height;

    // 枪管宽度
    private int barrelWidth;

    // 枪管高度
    private int barrelHeight;

    /**
     * 履带宽度
     */
    private int wheelWidth;

    /**
     * 履带高度减去坦克高度的差的一半
     */
    private int halfOverflowHeight;


    /**
     * 绘制坦克
     */
    public void fill(Graphics g) {
        // 绘制身体
        g.fillRect(x, y, width, height);
        // 绘制左边的履带
        g.fillRect(x - wheelWidth, y - halfOverflowHeight, wheelWidth, height + halfOverflowHeight * 2);
        // 绘制右边的履带
        g.fillRect(this.x + this.width, this.y - this.halfOverflowHeight, this.wheelWidth, this.height + this.halfOverflowHeight * 2);
        // 绘制枪管
        g.fillRect(this.x + this.width / 2 - this.barrelWidth / 2, this.y - this.barrelHeight, this.barrelWidth, this.barrelHeight);

    }

    /**
     * 坦克移动
     */
    public void move() {
        this.y--;
    }

    public int getWheelWidth() {
        return wheelWidth;
    }

    public void setWheelWidth(int wheelWidth) {
        this.wheelWidth = wheelWidth;
    }

    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public int getBarrelWidth() {
        return barrelWidth;
    }

    public void setBarrelWidth(int barrelWidth) {
        this.barrelWidth = barrelWidth;
    }

    public int getBarrelHeight() {
        return barrelHeight;
    }

    public void setBarrelHeight(int barrelHeight) {
        this.barrelHeight = barrelHeight;
    }

    public int getHalfOverflowHeight() {
        return halfOverflowHeight;
    }

    public void setHalfOverflowHeight(int halfOverflowHeight) {
        this.halfOverflowHeight = halfOverflowHeight;
    }
}
