package com.bigdata.tankbattle;

import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

/**
 * 主启动类
 */
public class TankBattleApplication {
    public static void main(String[] args) {
        Frame frame = new Frame();
        // 创建我自己的坦克
        Tank tank = new Tank();
        tank.setX(Tank.INIT_X);
        tank.setY(Tank.INIT_Y);
        tank.setWidth(Tank.WIDTH);
        tank.setHeight(Tank.HEIGHT);
        // 履带宽度
        tank.setWheelWidth(Tank.WHEEL_WIDTH);
        // halfOverflowHeight
        tank.setHalfOverflowHeight(Tank.HALF_OVERFLOW_HEIGHT);
        tank.setBarrelWidth(Tank.BARREL_WIDTH);
        tank.setBarrelHeight(Tank.BARREL_HEIGHT);

        // 点击 叉号 关闭窗口
        frame.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosing(WindowEvent e) {
                System.exit(0);
            }
        });

        frame.addKeyListener(new KeyListener() {
            @Override
            public void keyTyped(KeyEvent e) {

            }

            /**
             * 监听按下键盘按键
             * @param e
             */
            @Override
            public void keyPressed(KeyEvent e) {
                tank.move();
                System.out.println(tank.getY());
            }

            @Override
            public void keyReleased(KeyEvent e) {
                System.out.println("相互伤害啊");
            }
        });

        frame.setTitle("Tank Battle");
        frame.setBounds(100, 100, GamePanel.WIDTH, GamePanel.HEIGHT);

        // 创建画布对象
        GamePanel panel = new GamePanel(tank);
        // 设置画布x, y, width, height
        panel.setLocation(0, 0);
        panel.setSize(GamePanel.WIDTH, GamePanel.HEIGHT);
        panel.refresh();
        // 把画布对象添加到窗口中
        frame.add(panel);
        frame.setVisible(true);
    }
}
